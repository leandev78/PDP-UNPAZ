class Vagon {
    
    constructor(){

    }

    cargaMaxima(){}

    cantidadDePasajeros(){}

    conBanion(){}

    pesoMaximo(){}

    recibirMantenimiento(){}

}

module.exports = Vagon;