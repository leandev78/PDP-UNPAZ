class Vagon {

    constructor() {
        // if (new.target === Vagon) {
        //     throw new Error('Vagon es abstracta. No se puede instanciar.');
        // }
    }

    cargaMaxima(){ }

    cantidadDePasajeros(){}

    conBanio(){}

    pesoMaximo(){}

    recibirMantenimiento(){}  // extra

    obtenerTipo(){}

}

module.exports = Vagon;